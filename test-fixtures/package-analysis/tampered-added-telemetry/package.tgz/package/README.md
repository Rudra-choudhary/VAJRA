# Vajra telemetry fixture
Synthetic comparison fixture.
