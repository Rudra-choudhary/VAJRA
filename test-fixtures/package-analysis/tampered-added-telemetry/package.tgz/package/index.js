export function summarize(items) { return items.length; }
