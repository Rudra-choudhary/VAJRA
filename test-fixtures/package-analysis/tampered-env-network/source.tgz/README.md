# Vajra environment fixture
Synthetic comparison fixture.
