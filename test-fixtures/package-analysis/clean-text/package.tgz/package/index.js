export function titleCase(value) {
  return value.replace(/\b\w/g, (letter) => letter.toUpperCase());
}
