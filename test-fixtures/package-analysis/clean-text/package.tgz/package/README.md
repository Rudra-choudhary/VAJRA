# Vajra clean text fixture
Synthetic control package.
