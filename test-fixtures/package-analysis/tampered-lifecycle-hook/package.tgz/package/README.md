# Vajra lifecycle fixture
Synthetic comparison fixture.
