console.log("Synthetic fixture install hook; no changes made.");
