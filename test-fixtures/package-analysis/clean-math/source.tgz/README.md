# Vajra clean math fixture
Synthetic control package.
