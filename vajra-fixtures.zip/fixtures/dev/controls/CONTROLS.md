# Control releases (dev split)

> CONTROL: real, unmodified npm releases used as clean references. Nothing here is tampered. Each tarball was downloaded, its sha1 matched to the npm registry, and its source commit fetched from GitHub. No package code or build step was run.

| # | Package@version | Type | Repo | Commit | Files / bytes | npm provenance |
|---|---|---|---|---|---|---|
| 1 | `ms@2.1.3` | (a) plain JS | vercel/ms | `1c6264b79549` | 4 / 6721 | no |
| 2 | `picocolors@1.1.1` | (a) plain JS | alexeyraspopov/picocolors | `6f0a4638348e` | 7 / 6373 | no |
| 3 | `kleur@4.1.5` | (a) plain JS | lukeed/kleur | `fa3454483899` | 9 / 20250 | no |
| 4 | `ts-custom-error@3.3.1` | (b) TS to JS | adriengibrat/ts-custom-error | `43e15da6b99f` | 16 / 58111 | no |
| 5 | `tiny-invariant@1.3.3` | (b) TS to JS | alexreardon/tiny-invariant | `a6b189389aea` | 13 / 14809 | no |
| 6 | `mitt@3.0.1` | (c) bundled | developit/mitt | `b240473b5707` | 10 / 26444 | no |
| 7 | `@babel/helper-string-parser@8.0.8` | (d) monorepo | babel/babel (`packages/babel-helper-string-parser`) | `220840194f56` | 5 / 11724 | yes |
| 8 | `@vue/shared@3.5.44` | (d) monorepo | vuejs/core (`packages/shared`) | `bf5f0dd877dd` | 8 / 92585 | yes |

Full 40-character commits and per-file results are in `controls.json`.

## 1. ms@2.1.3

- **Why chosen:** Smallest possible clean baseline: 4 files, hand-written plain JS, no build step. Every published file is byte-identical to source, so any finding is a false positive. Also the base for the tampered fixtures.
- **Commit:** `1c6264b795492e8fdecbc82cb8802fcfbfc08d26` (registry gitHead (equals tag 2.1.3))
- **Expected packaging noise:** None expected.
- **Expected tool result:** Zero findings.
- **Measured:** 4 identical, 0 differ, 0 absent from source (of 4 files)

## 2. picocolors@1.1.1

- **Why chosen:** Plain JS shipped as written, plus a publish-time package.json rewrite. Tests that metadata cleanup is not flagged.
- **Commit:** `6f0a4638348ed20633d623ee973f9c9a96f65104` (registry gitHead)
- **Expected packaging noise:** package.json: version differs (source tree says 1.1.0, published says 1.1.1), and dev-only fields (scripts, devDependencies, prettier and clean-publish config) are stripped. README.md is shortened. All .js and .d.ts files are identical.
- **Expected tool result:** Only package.json and README.md differences, classified explained_packaging.
- **Measured:** 5 identical, 2 differ, 0 absent from source (of 7 files)

## 3. kleur@4.1.5

- **Why chosen:** Plain JS where the CommonJS files do not exist in source. The package defines "build": "node build" (seen in registry metadata). Tests detection of generated-but-benign files.
- **Commit:** `fa3454483899ddab550d08c18c028e6db1aab0e5` (registry gitHead)
- **Expected packaging noise:** index.js and colors.js (CommonJS) are not present in the source tree. Their ESM twins index.mjs and colors.mjs are identical to source.
- **Expected tool result:** Two files absent from source, classified explained_packaging (generated twin of an identical ESM file).
- **Measured:** 7 identical, 0 differ, 2 absent from source (of 9 files)

## 4. ts-custom-error@3.3.1

- **Why chosen:** TypeScript project published as compiled JS in dist/ with type declarations and source maps. Includes an odd nested path (dist/dist/src/index.d.ts) that a naive path-matcher may mishandle.
- **Commit:** `43e15da6b99f5441723e10dbfd9d527e2aa8fead` (registry gitHead)
- **Expected packaging noise:** All 11 files under dist/ are absent from source (JS in several module formats, source maps, type declarations, including dist/dist/src/index.d.ts). Docs and package.json are identical.
- **Expected tool result:** dist/ files classified explained_packaging. Docs and package.json produce no findings.
- **Measured:** 5 identical, 0 differ, 11 absent from source (of 16 files)

## 5. tiny-invariant@1.3.3

- **Why chosen:** TypeScript package that ships both built dist/ and the original src/ files, so the analyzer can compare shipped source to repo source directly.
- **Commit:** `a6b189389aeaf2b6b2d8517bd3869ec993de4507` (registry gitHead)
- **Expected packaging noise:** 8 files under dist/ (including dist/esm/package.json) are absent from source. The shipped src/tiny-invariant.ts and src/tiny-invariant.flow.js are identical to source.
- **Expected tool result:** dist/ files classified explained_packaging. Shipped src/ files match exactly and produce no findings.
- **Measured:** 5 identical, 0 differ, 8 absent from source (of 13 files)

## 6. mitt@3.0.1

- **Why chosen:** Bundled output with source maps from a documented bundler step: registry metadata shows "bundle": "microbundle -f es,cjs,umd". Small and cleanly bundled.
- **Commit:** `b240473b5707857ba2c6a8e6d707c28d1e39da49` (registry gitHead)
- **Expected packaging noise:** dist/ bundles (6 files: CommonJS, ES module, UMD, each with a source map) and a root index.d.ts are not present in the source tree at that commit.
- **Expected tool result:** dist/ and index.d.ts classified explained_packaging.
- **Measured:** 3 identical, 0 differ, 7 absent from source (of 10 files)

## 7. @babel/helper-string-parser@8.0.8

- **Why chosen:** Monorepo package with npm provenance (SLSA). Source lives in a subdirectory and is written in TypeScript. Tests subdirectory mapping and commit resolution through a tag when gitHead is missing.
- **Commit:** `220840194f5660cbacc88ebe345fc230077e31e5` (tag v8.0.8 (annotated tag, commit is the peeled value); registry has no gitHead for this version)
- **Expected packaging noise:** lib/index.js and lib/index.d.ts are built from src/index.ts. LICENSE is not in the package directory in source. package.json differs: a workspace "catalog:dev" dependency reference is resolved to a concrete version range (^0.2.0) and the trailing newline is removed.
- **Expected tool result:** lib/ files and LICENSE classified explained_packaging. package.json difference explained as workspace dependency resolution.
- **Measured:** 1 identical, 1 differ, 3 absent from source (of 5 files)

## 8. @vue/shared@3.5.44

- **Why chosen:** Larger monorepo package with npm provenance (SLSA) and several built output flavors. Tests directory mapping, tag resolution, and many generated files at once.
- **Commit:** `bf5f0dd877dd3c23ce85c2cbc1dd771567e84c8c` (tag v3.5.44 (lightweight tag); registry has no gitHead for this version)
- **Expected packaging noise:** 4 files under dist/ (development and production CommonJS builds, ES-module bundler build, type declarations) are not in source. package.json differs only by a missing trailing newline. index.js, LICENSE and README.md are identical.
- **Expected tool result:** dist/ files classified explained_packaging. package.json whitespace-only difference.
- **Measured:** 3 identical, 1 differ, 4 absent from source (of 8 files)

