# ms-2.1.3-05-harmless-packaging-change

> FIXTURE: synthetic tampered copy of a real package, built for VAJRA development testing. NOT a real npm release. Do not publish it. Do not install it outside a sandbox.

**Split:** dev (never mix with held-out inputs)

## Input identity

| Field | Value |
|---|---|
| Package | `ms@2.1.3` (name and version deliberately left unchanged) |
| Real source repo | https://github.com/vercel/ms |
| Real release commit | `1c6264b795492e8fdecbc82cb8802fcfbfc08d26` (tag `2.1.3`) |
| Base archive | `../ms-2.1.3.orig.tgz`, sha1 `574c8138ce1d2b5861f0b44579dbadd60c6615b2` (matches npm registry), sha256 `f6616e15e530ed552f9daa2d3ce71963947c6bc7c98c9b64fd3e673fd02622c6` |
| This archive | `FIXTURE-ms-2.1.3-05-harmless-packaging-change.tgz`, sha256 `b0e9044ef76a05730b75785efee76e07f842a6431879482041f123d9dda8997e`, 3079 bytes |
| Built by | `tools/build_tampered.mjs` (deterministic) |

## What was planted

- **identifier_rename_and_comment** in `index.js` (parse(): lines 59-104, comment at line 61). Renamed the local variable n to amount inside parse() (8 lines) and added one comment line. Behavior is unchanged.

## Expected result

**Overall classification:** `explained_packaging`

| Path | Location | Classification | Why |
|---|---|---|---|
| `index.js` | parse() lines 59-104 | `explained_packaging` | Differs from source only by a local-identifier rename and a comment. The AST is identical after stripping comments and normalizing local names. |

Every other file in the archive should produce no finding. They are byte-identical to source at the release commit.

## Notes

- A plain byte diff flags index.js. Expected behavior needs normalization (comment stripping + local identifier canonicalization) before judging.
- In a real release this kind of change comes from minifiers or bundlers. Here it is applied to a file that is normally byte-identical, which is exactly why it is a good false-positive test.

## Exact diff against the base archive

```diff
diff -ruN a/package/index.js b/package/index.js
--- a/package/index.js
+++ b/package/index.js
@@ -56,47 +56,48 @@
   if (!match) {
     return;
   }
-  var n = parseFloat(match[1]);
+  var amount = parseFloat(match[1]);
   var type = (match[2] || 'ms').toLowerCase();
+  // repackaged: local variable renamed for readability (no behavior change)
   switch (type) {
     case 'years':
     case 'year':
     case 'yrs':
     case 'yr':
     case 'y':
-      return n * y;
+      return amount * y;
     case 'weeks':
     case 'week':
     case 'w':
-      return n * w;
+      return amount * w;
     case 'days':
     case 'day':
     case 'd':
-      return n * d;
+      return amount * d;
     case 'hours':
     case 'hour':
     case 'hrs':
     case 'hr':
     case 'h':
-      return n * h;
+      return amount * h;
     case 'minutes':
     case 'minute':
     case 'mins':
     case 'min':
     case 'm':
-      return n * m;
+      return amount * m;
     case 'seconds':
     case 'second':
     case 'secs':
     case 'sec':
     case 's':
-      return n * s;
+      return amount * s;
     case 'milliseconds':
     case 'millisecond':
     case 'msecs':
     case 'msec':
     case 'ms':
-      return n;
+      return amount;
     default:
       return undefined;
   }
```
