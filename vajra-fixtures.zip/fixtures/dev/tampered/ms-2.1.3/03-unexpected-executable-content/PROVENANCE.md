# ms-2.1.3-03-unexpected-executable-content

> FIXTURE: synthetic tampered copy of a real package, built for VAJRA development testing. NOT a real npm release. Do not publish it. Do not install it outside a sandbox.

**Split:** dev (never mix with held-out inputs)

## Input identity

| Field | Value |
|---|---|
| Package | `ms@2.1.3` (name and version deliberately left unchanged) |
| Real source repo | https://github.com/vercel/ms |
| Real release commit | `1c6264b795492e8fdecbc82cb8802fcfbfc08d26` (tag `2.1.3`) |
| Base archive | `../ms-2.1.3.orig.tgz`, sha1 `574c8138ce1d2b5861f0b44579dbadd60c6615b2` (matches npm registry), sha256 `f6616e15e530ed552f9daa2d3ce71963947c6bc7c98c9b64fd3e673fd02622c6` |
| This archive | `FIXTURE-ms-2.1.3-03-unexpected-executable-content.tgz`, sha256 `56aff2630a892313802c477ba79961ec2ff36642be3d590d92694e137793bb61`, 3149 bytes |
| Built by | `tools/build_tampered.mjs` (deterministic) |

## What was planted

- **executable_file_added** in `bin/setup.sh` (whole file, mode 0755). New shell script with a shebang and the executable bit set. It only echoes a marker line. Nothing references it.

## Expected result

**Overall classification:** `suspicious_change`

| Path | Location | Classification | Why |
|---|---|---|---|
| `bin/setup.sh` | whole file (mode 0755, shebang on line 1) | `suspicious_change` | Executable file with a shebang that is absent from source at the release commit and outside package.json "files". |

Every other file in the archive should produce no finding. They are byte-identical to source at the release commit.

## Notes

- Only a .sh file is planted. No binary blob was created.

## Exact diff against the base archive

```diff
diff -ruN a/package/bin/setup.sh b/package/bin/setup.sh
--- a/package/bin/setup.sh
+++ b/package/bin/setup.sh
@@ -0,0 +1,3 @@
+#!/bin/sh
+# VAJRA FIXTURE (inert sample). Not referenced by package.json. Planted to test executable detection.
+echo "VAJRA_FIXTURE_MARKER:setup.sh"
```
