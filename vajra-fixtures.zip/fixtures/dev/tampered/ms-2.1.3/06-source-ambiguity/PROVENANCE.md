# ms-2.1.3-06-source-ambiguity

> FIXTURE: synthetic tampered copy of a real package, built for VAJRA development testing. NOT a real npm release. Do not publish it. Do not install it outside a sandbox.

**Split:** dev (never mix with held-out inputs)

## Input identity

| Field | Value |
|---|---|
| Package | `ms@2.1.3` (name and version deliberately left unchanged) |
| Real source repo | https://github.com/vercel/ms |
| Real release commit | `1c6264b795492e8fdecbc82cb8802fcfbfc08d26` (tag `2.1.3`) |
| Base archive | `../ms-2.1.3.orig.tgz`, sha1 `574c8138ce1d2b5861f0b44579dbadd60c6615b2` (matches npm registry), sha256 `f6616e15e530ed552f9daa2d3ce71963947c6bc7c98c9b64fd3e673fd02622c6` |
| This archive | `FIXTURE-ms-2.1.3-06-source-ambiguity.tgz`, sha256 `a319946c34d727077bec76d9fad34611469ea8b60f4c2429fb1174856921ec1f`, 3065 bytes |
| Built by | `tools/build_tampered.mjs` (deterministic) |

## What was planted

- **conflicting_source_pointer** in `package.json` (line 38, JSON pointer /gitHead). Added gitHead=7920885eb232fbe7a5efdab956d3e7c507c92ddf. That is a real commit in https://github.com/vercel/ms (the 2.1.2 release), but the package version says 2.1.3, whose tag points to 1c6264b795492e8fdecbc82cb8802fcfbfc08d26. The package files themselves are unchanged from the real 2.1.3 release.

## Expected result

**Overall classification:** `unresolved`

| Path | Location | Classification | Why |
|---|---|---|---|
| `package.json` | /gitHead (line 38) | `unresolved` | Two candidate source commits disagree: gitHead -> 7920885eb232 (tag 2.1.2) vs version tag 2.1.3 -> 1c6264b79549. No provenance attestation exists to choose between them. The tool should report both candidates and not silently pick one. |

Every other file in the archive should produce no finding. They are byte-identical to source at the release commit.

## Notes

- index.js at the 2.1.2 commit differs from the 2.1.3 file by whitespace only ("function(val, options)" vs "function (val, options)"). A tool that trusts gitHead will see a tiny difference. A tool that trusts the tag will see none. Neither pointer is authoritative here.
- Policy note: if your resolver deliberately prefers the version tag and records that choice, document it. This fixture expects the conservative result, unresolved, with both candidates listed as evidence.

## Exact diff against the base archive

```diff
diff -ruN a/package/package.json b/package/package.json
--- a/package/package.json
+++ b/package/package.json
@@ -34,5 +34,6 @@
     "lint-staged": "5.0.0",
     "mocha": "4.0.1",
     "prettier": "2.0.5"
-  }
+  },
+  "gitHead": "7920885eb232fbe7a5efdab956d3e7c507c92ddf"
 }
```
