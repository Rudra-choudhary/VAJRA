# ms-2.1.3-02-outbound-request-injection

> FIXTURE: synthetic tampered copy of a real package, built for VAJRA development testing. NOT a real npm release. Do not publish it. Do not install it outside a sandbox.

**Split:** dev (never mix with held-out inputs)

## Input identity

| Field | Value |
|---|---|
| Package | `ms@2.1.3` (name and version deliberately left unchanged) |
| Real source repo | https://github.com/vercel/ms |
| Real release commit | `1c6264b795492e8fdecbc82cb8802fcfbfc08d26` (tag `2.1.3`) |
| Base archive | `../ms-2.1.3.orig.tgz`, sha1 `574c8138ce1d2b5861f0b44579dbadd60c6615b2` (matches npm registry), sha256 `f6616e15e530ed552f9daa2d3ce71963947c6bc7c98c9b64fd3e673fd02622c6` |
| This archive | `FIXTURE-ms-2.1.3-02-outbound-request-injection.tgz`, sha256 `24441c9aa25830ba821a00bb65097b321c2ed79b2347eff2ef6eacb49c1e059e`, 3239 bytes |
| Built by | `tools/build_tampered.mjs` (deterministic) |

## What was planted

- **file_added_with_network_call** in `lib/telemetry.js` (line 8). New file that calls https.get() against https://fixture.invalid/ (reserved TLD). Exports a function that nothing imports or calls, so it is inert.

## Expected result

**Overall classification:** `suspicious_change`

| Path | Location | Classification | Why |
|---|---|---|---|
| `lib/telemetry.js` | lines 4-10 (https.get at line 8) | `suspicious_change` | File does not exist in source at the release commit, is outside package.json "files" ([index.js]), and makes an outbound HTTPS request. |

Every other file in the archive should produce no finding. They are byte-identical to source at the release commit.

## Notes

- The file is not wired into index.js, so a pure "does install run it" check will not trigger. Detection must come from the new-file + network-call evidence.
- package.json "files" lists only index.js. A file under lib/ is itself an anomaly worth reporting.

## Exact diff against the base archive

```diff
diff -ruN a/package/lib/telemetry.js b/package/lib/telemetry.js
--- a/package/lib/telemetry.js
+++ b/package/lib/telemetry.js
@@ -0,0 +1,10 @@
+'use strict';
+// VAJRA FIXTURE (inert sample, never imported, never called).
+// Planted on purpose to test outbound-request detection.
+const https = require('https');
+
+module.exports = function report() {
+  return https
+    .get('https://fixture.invalid/vajra-marker?src=ms-fixture-02', function () {})
+    .on('error', function () {});
+};
```
