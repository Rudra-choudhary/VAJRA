# ms-2.1.3-01-lifecycle-script-injection

> FIXTURE: synthetic tampered copy of a real package, built for VAJRA development testing. NOT a real npm release. Do not publish it. Do not install it outside a sandbox.

**Split:** dev (never mix with held-out inputs)

## Input identity

| Field | Value |
|---|---|
| Package | `ms@2.1.3` (name and version deliberately left unchanged) |
| Real source repo | https://github.com/vercel/ms |
| Real release commit | `1c6264b795492e8fdecbc82cb8802fcfbfc08d26` (tag `2.1.3`) |
| Base archive | `../ms-2.1.3.orig.tgz`, sha1 `574c8138ce1d2b5861f0b44579dbadd60c6615b2` (matches npm registry), sha256 `f6616e15e530ed552f9daa2d3ce71963947c6bc7c98c9b64fd3e673fd02622c6` |
| This archive | `FIXTURE-ms-2.1.3-01-lifecycle-script-injection.tgz`, sha256 `1b7783e2cfebce74759b1f34fcc36afe224e5f93110f7c0d2d0e3967ca122338`, 3158 bytes |
| Built by | `tools/build_tampered.mjs` (deterministic) |

## What was planted

- **lifecycle_script_added** in `package.json` (line 11, JSON pointer /scripts/postinstall). Added a postinstall script. It prints VAJRA_FIXTURE_MARKER:postinstall. It contains a require('https').get(...) call to https://fixture.invalid/ (reserved TLD, never resolves) that only runs if VAJRA_FIXTURE_ALLOW_NET=1, which nothing sets.

## Expected result

**Overall classification:** `suspicious_change`

| Path | Location | Classification | Why |
|---|---|---|---|
| `package.json` | /scripts/postinstall (line 11) | `suspicious_change` | New install-time lifecycle script that is absent from source at the release commit and performs an outbound HTTPS call. |

Every other file in the archive should produce no finding. They are byte-identical to source at the release commit.

## Notes

- Only package.json differs from the base archive. index.js and all other files are byte-identical to source.

## Exact diff against the base archive

```diff
diff -ruN a/package/package.json b/package/package.json
--- a/package/package.json
+++ b/package/package.json
@@ -8,6 +8,7 @@
     "index.js"
   ],
   "scripts": {
+    "postinstall": "node -e \"console.log('VAJRA_FIXTURE_MARKER:postinstall');if(process.env.VAJRA_FIXTURE_ALLOW_NET==='1'){require('https').get('https://fixture.invalid/vajra-marker').on('error',function(){})}\"",
     "precommit": "lint-staged",
     "lint": "eslint lib/* bin/*",
     "test": "mocha tests.js"
```
