# ms-2.1.3-04-source-modification

> FIXTURE: synthetic tampered copy of a real package, built for VAJRA development testing. NOT a real npm release. Do not publish it. Do not install it outside a sandbox.

**Split:** dev (never mix with held-out inputs)

## Input identity

| Field | Value |
|---|---|
| Package | `ms@2.1.3` (name and version deliberately left unchanged) |
| Real source repo | https://github.com/vercel/ms |
| Real release commit | `1c6264b795492e8fdecbc82cb8802fcfbfc08d26` (tag `2.1.3`) |
| Base archive | `../ms-2.1.3.orig.tgz`, sha1 `574c8138ce1d2b5861f0b44579dbadd60c6615b2` (matches npm registry), sha256 `f6616e15e530ed552f9daa2d3ce71963947c6bc7c98c9b64fd3e673fd02622c6` |
| This archive | `FIXTURE-ms-2.1.3-04-source-modification.tgz`, sha256 `13676a5dd4d8fddfd0d594f4c93a11309a27471ea718504684c2c47a4a751b10`, 3020 bytes |
| Built by | `tools/build_tampered.mjs` (deterministic) |

## What was planted

- **source_behavior_changed** in `index.js` (line 75, inside parse()). In parse(), the 'd' (days) case now returns n * h instead of n * d. ms('2d') returns 7200000 instead of 172800000.

## Expected result

**Overall classification:** `suspicious_change`

| Path | Location | Classification | Why |
|---|---|---|---|
| `index.js` | line 75 (parse, case 'd') | `suspicious_change` | index.js is byte-identical to source in the base release. Here the published file differs by a behavioral change (different operand), not by comment, whitespace or identifier renaming. |

Every other file in the archive should produce no finding. They are byte-identical to source at the release commit.

## Notes

- A real attacker change would be subtler or more malicious. This one is deliberately simple and verifiable by running ms("2d").

## Exact diff against the base archive

```diff
diff -ruN a/package/index.js b/package/index.js
--- a/package/index.js
+++ b/package/index.js
@@ -72,7 +72,7 @@
     case 'days':
     case 'day':
     case 'd':
-      return n * d;
+      return n * h;
     case 'hours':
     case 'hour':
     case 'hrs':
```
