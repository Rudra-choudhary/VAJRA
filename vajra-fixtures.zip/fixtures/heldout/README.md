# Held-out evaluation inputs

**Intentionally empty.** Only organizer-provided held-out inputs go here, and only when the evaluation is run.

Rules:
- Never copy anything from `fixtures/dev/` into this folder, or the reverse.
- Never tune thresholds, prompts or rules against anything in this folder.
- Never commit expected answers for held-out inputs.
- If a held-out input ever leaks into development, it is no longer held-out. Discard it for evaluation purposes.
