// VAJRA dev fixtures: builds six tampered copies of ms@2.1.3 from the pristine registry tarball.
//
// FIXTURE TOOLING ONLY. Output archives are synthetic and must never be published.
// This script edits files and repacks archives. It does NOT execute any package code,
// lifecycle script, or build step.
//
// Usage (repo root):  node tools/build_tampered.mjs

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { execFileSync, spawnSync } from 'node:child_process';

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const OUT = path.join(ROOT, 'fixtures/dev/tampered/ms-2.1.3');
const ORIG = path.join(OUT, 'ms-2.1.3.orig.tgz');

const BASE = {
  name: 'ms',
  version: '2.1.3',
  repo: 'https://github.com/vercel/ms',
  release_commit: '1c6264b795492e8fdecbc82cb8802fcfbfc08d26', // tag 2.1.3, equals registry gitHead
  registry_tarball_sha1: '574c8138ce1d2b5861f0b44579dbadd60c6615b2',
  wrong_commit: '7920885eb232fbe7a5efdab956d3e7c507c92ddf', // tag 2.1.2 (real, different release)
};
const NPM_MTIME = '1985-10-26 08:15:00 UTC'; // what npm uses for tarball entries
const LABEL =
  'FIXTURE: synthetic tampered copy of a real package, built for VAJRA development testing. ' +
  'NOT a real npm release. Do not publish it. Do not install it outside a sandbox.';

const hash = (f, alg) => crypto.createHash(alg).update(fs.readFileSync(f)).digest('hex');
const mk = (p) => fs.mkdirSync(p, { recursive: true });
const read = (p) => fs.readFileSync(p, 'utf8');
const lineOf = (file, needle) => {
  const i = read(file).split('\n').findIndex((l) => l.includes(needle));
  assert(i >= 0, `needle not found: ${needle}`);
  return i + 1;
};
function extract(tgz, dir) {
  mk(dir);
  execFileSync('tar', ['-xzf', tgz, '-C', dir]); // entries live under package/
}
function normalizeModes(pkgDir, execFiles = []) {
  const walk = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { fs.chmodSync(p, 0o755); walk(p); }
      else fs.chmodSync(p, execFiles.includes(path.relative(pkgDir, p)) ? 0o755 : 0o644);
    }
  };
  fs.chmodSync(pkgDir, 0o755);
  walk(pkgDir);
}
function pack(stage, out) {
  execFileSync('bash', ['-c',
    `cd "${stage}" && tar --sort=name --mtime='${NPM_MTIME}' --owner=0 --group=0 --numeric-owner -cf - package | gzip -n -9 > "${out}"`]);
}
function unifiedDiff(a, b) {
  const r = spawnSync('diff', ['-ruN', 'a/package', 'b/package'], { cwd: path.dirname(a) });
  return r.stdout.toString().replace(/^(---|\+\+\+) (\S+)\t.*$/gm, '$1 $2');
}

// ---------------------------------------------------------------- fixtures
const POSTINSTALL_CMD =
  `node -e "console.log('VAJRA_FIXTURE_MARKER:postinstall');` +
  `if(process.env.VAJRA_FIXTURE_ALLOW_NET==='1'){require('https').get('https://fixture.invalid/vajra-marker').on('error',function(){})}"`;

const fixtures = [
  {
    id: '01-lifecycle-script-injection',
    title: 'Lifecycle-script injection',
    classification: 'suspicious_change',
    apply(pkg) {
      const p = path.join(pkg, 'package.json');
      const src = read(p);
      const open = '"scripts": {\n';
      assert(src.includes(open));
      fs.writeFileSync(p, src.replace(open, open + `    "postinstall": ${JSON.stringify(POSTINSTALL_CMD)},\n`));
      JSON.parse(read(p));
      const ln = lineOf(p, '"postinstall"');
      return {
        planted: [{
          kind: 'lifecycle_script_added', path: 'package.json', location: `line ${ln}, JSON pointer /scripts/postinstall`,
          description: 'Added a postinstall script. It prints VAJRA_FIXTURE_MARKER:postinstall. It contains a require(\'https\').get(...) call to https://fixture.invalid/ (reserved TLD, never resolves) that only runs if VAJRA_FIXTURE_ALLOW_NET=1, which nothing sets.',
        }],
        findings: [{
          path: 'package.json', location: `/scripts/postinstall (line ${ln})`, classification: 'suspicious_change',
          evidence: 'New install-time lifecycle script that is absent from source at the release commit and performs an outbound HTTPS call.',
        }],
        notes: ['Only package.json differs from the base archive. index.js and all other files are byte-identical to source.'],
      };
    },
  },
  {
    id: '02-outbound-request-injection',
    title: 'Outbound-request injection (new file)',
    classification: 'suspicious_change',
    apply(pkg) {
      mk(path.join(pkg, 'lib'));
      const p = path.join(pkg, 'lib/telemetry.js');
      fs.writeFileSync(p,
`'use strict';
// VAJRA FIXTURE (inert sample, never imported, never called).
// Planted on purpose to test outbound-request detection.
const https = require('https');

module.exports = function report() {
  return https
    .get('https://fixture.invalid/vajra-marker?src=ms-fixture-02', function () {})
    .on('error', function () {});
};
`);
      const ln = lineOf(p, 'https');
      const lg = lineOf(p, '.get(');
      return {
        planted: [{
          kind: 'file_added_with_network_call', path: 'lib/telemetry.js', location: `line ${lg}`,
          description: 'New file that calls https.get() against https://fixture.invalid/ (reserved TLD). Exports a function that nothing imports or calls, so it is inert.',
        }],
        findings: [{
          path: 'lib/telemetry.js', location: `lines ${ln}-${lg + 2} (https.get at line ${lg})`, classification: 'suspicious_change',
          evidence: 'File does not exist in source at the release commit, is outside package.json "files" ([index.js]), and makes an outbound HTTPS request.',
        }],
        notes: [
          'The file is not wired into index.js, so a pure "does install run it" check will not trigger. Detection must come from the new-file + network-call evidence.',
          'package.json "files" lists only index.js. A file under lib/ is itself an anomaly worth reporting.',
        ],
      };
    },
  },
  {
    id: '03-unexpected-executable-content',
    title: 'Unexpected executable content (.sh)',
    classification: 'suspicious_change',
    apply(pkg) {
      mk(path.join(pkg, 'bin'));
      const p = path.join(pkg, 'bin/setup.sh');
      fs.writeFileSync(p,
`#!/bin/sh
# VAJRA FIXTURE (inert sample). Not referenced by package.json. Planted to test executable detection.
echo "VAJRA_FIXTURE_MARKER:setup.sh"
`);
      return {
        execFiles: ['bin/setup.sh'],
        planted: [{
          kind: 'executable_file_added', path: 'bin/setup.sh', location: 'whole file, mode 0755',
          description: 'New shell script with a shebang and the executable bit set. It only echoes a marker line. Nothing references it.',
        }],
        findings: [{
          path: 'bin/setup.sh', location: 'whole file (mode 0755, shebang on line 1)', classification: 'suspicious_change',
          evidence: 'Executable file with a shebang that is absent from source at the release commit and outside package.json "files".',
        }],
        notes: ['Only a .sh file is planted. No binary blob was created.'],
      };
    },
  },
  {
    id: '04-source-modification',
    title: 'Source modification (function body changed)',
    classification: 'suspicious_change',
    apply(pkg) {
      const p = path.join(pkg, 'index.js');
      const src = read(p);
      const before = "    case 'd':\n      return n * d;\n";
      assert.equal(src.split(before).length - 1, 1);
      fs.writeFileSync(p, src.replace(before, "    case 'd':\n      return n * h;\n"));
      const ln = lineOf(p, 'return n * h;') ; // first occurrence is the changed line (days come before hours)
      return {
        planted: [{
          kind: 'source_behavior_changed', path: 'index.js', location: `line ${ln}, inside parse()`,
          description: "In parse(), the 'd' (days) case now returns n * h instead of n * d. ms('2d') returns 7200000 instead of 172800000.",
        }],
        findings: [{
          path: 'index.js', location: `line ${ln} (parse, case 'd')`, classification: 'suspicious_change',
          evidence: 'index.js is byte-identical to source in the base release. Here the published file differs by a behavioral change (different operand), not by comment, whitespace or identifier renaming.',
        }],
        notes: ['A real attacker change would be subtler or more malicious. This one is deliberately simple and verifiable by running ms("2d").'],
      };
    },
  },
  {
    id: '05-harmless-packaging-change',
    title: 'Harmless packaging change (rename + comment)',
    classification: 'explained_packaging',
    apply(pkg) {
      const p = path.join(pkg, 'index.js');
      const lines = read(p).split('\n');
      const start = lines.findIndex((l) => l.startsWith('function parse(str)'));
      let end = start;
      while (lines[end] !== '}') end++;
      let changed = 0;
      for (let i = start; i <= end; i++) {
        const next = lines[i].replace(/\bn\b/g, 'amount');
        if (next !== lines[i]) { lines[i] = next; changed++; }
      }
      assert.equal(changed, 8, 'expected 8 changed lines inside parse()');
      const sw = lines.findIndex((l, i) => i > start && i < end && l.includes('switch (type)'));
      lines.splice(sw, 0, '  // repackaged: local variable renamed for readability (no behavior change)');
      fs.writeFileSync(p, lines.join('\n'));
      const a = lineOf(p, 'var amount');
      const c = lineOf(p, '// repackaged:');
      return {
        planted: [{
          kind: 'identifier_rename_and_comment', path: 'index.js', location: `parse(): lines ${a}-${end + 2}, comment at line ${c}`,
          description: 'Renamed the local variable n to amount inside parse() (8 lines) and added one comment line. Behavior is unchanged.',
        }],
        findings: [{
          path: 'index.js', location: `parse() lines ${a}-${end + 2}`, classification: 'explained_packaging',
          evidence: 'Differs from source only by a local-identifier rename and a comment. The AST is identical after stripping comments and normalizing local names.',
        }],
        notes: [
          'A plain byte diff flags index.js. Expected behavior needs normalization (comment stripping + local identifier canonicalization) before judging.',
          'In a real release this kind of change comes from minifiers or bundlers. Here it is applied to a file that is normally byte-identical, which is exactly why it is a good false-positive test.',
        ],
      };
    },
  },
  {
    id: '06-source-ambiguity',
    title: 'Source ambiguity (wrong commit pointer)',
    classification: 'unresolved',
    apply(pkg) {
      const p = path.join(pkg, 'package.json');
      const src = read(p);
      const i = src.lastIndexOf('\n}');
      assert(i > 0);
      fs.writeFileSync(p, `${src.slice(0, i)},\n  "gitHead": "${BASE.wrong_commit}"${src.slice(i)}`);
      JSON.parse(read(p));
      const ln = lineOf(p, '"gitHead"');
      return {
        planted: [{
          kind: 'conflicting_source_pointer', path: 'package.json', location: `line ${ln}, JSON pointer /gitHead`,
          description: `Added gitHead=${BASE.wrong_commit}. That is a real commit in ${BASE.repo} (the 2.1.2 release), but the package version says 2.1.3, whose tag points to ${BASE.release_commit}. The package files themselves are unchanged from the real 2.1.3 release.`,
        }],
        findings: [{
          path: 'package.json', location: `/gitHead (line ${ln})`, classification: 'unresolved',
          evidence: `Two candidate source commits disagree: gitHead -> ${BASE.wrong_commit.slice(0, 12)} (tag 2.1.2) vs version tag 2.1.3 -> ${BASE.release_commit.slice(0, 12)}. No provenance attestation exists to choose between them. The tool should report both candidates and not silently pick one.`,
        }],
        notes: [
          'index.js at the 2.1.2 commit differs from the 2.1.3 file by whitespace only ("function(val, options)" vs "function (val, options)"). A tool that trusts gitHead will see a tiny difference. A tool that trusts the tag will see none. Neither pointer is authoritative here.',
          'Policy note: if your resolver deliberately prefers the version tag and records that choice, document it. This fixture expects the conservative result, unresolved, with both candidates listed as evidence.',
        ],
      };
    },
  },
];

// ---------------------------------------------------------------- build
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'vajra-fx-'));
assert.equal(hash(ORIG, 'sha1'), BASE.registry_tarball_sha1, 'base archive does not match the registry sha1');
const origSha256 = hash(ORIG, 'sha256');
const manifest = [];

for (const fx of fixtures) {
  const work = path.join(tmp, fx.id);
  const aDir = path.join(work, 'a');
  const bDir = path.join(work, 'b');
  extract(ORIG, aDir);
  extract(ORIG, bDir);
  const res = fx.apply(path.join(bDir, 'package'));
  normalizeModes(path.join(bDir, 'package'), res.execFiles || []);

  const dir = path.join(OUT, fx.id);
  mk(dir);
  const fileName = `FIXTURE-ms-2.1.3-${fx.id}.tgz`;
  const archive = path.join(dir, fileName);
  pack(bDir, archive);
  const diff = unifiedDiff(aDir, bDir);
  const sha256 = hash(archive, 'sha256');
  const size = fs.statSync(archive).size;

  const record = {
    fixture_id: `ms-2.1.3-${fx.id}`,
    label: LABEL,
    split: 'dev',
    base: {
      package: BASE.name, version: BASE.version, repo: BASE.repo, release_commit: BASE.release_commit,
      base_archive: '../ms-2.1.3.orig.tgz', base_archive_sha1_registry: BASE.registry_tarball_sha1, base_archive_sha256: origSha256,
    },
    archive: { file: fileName, sha256, size_bytes: size },
    planted: res.planted,
    expected: { overall_classification: fx.classification, findings: res.findings },
  };
  fs.writeFileSync(path.join(dir, 'fixture.json'), JSON.stringify(record, null, 2) + '\n');

  const md = `# ${record.fixture_id}

> ${LABEL}

**Split:** dev (never mix with held-out inputs)

## Input identity

| Field | Value |
|---|---|
| Package | \`${BASE.name}@${BASE.version}\` (name and version deliberately left unchanged) |
| Real source repo | ${BASE.repo} |
| Real release commit | \`${BASE.release_commit}\` (tag \`2.1.3\`) |
| Base archive | \`../ms-2.1.3.orig.tgz\`, sha1 \`${BASE.registry_tarball_sha1}\` (matches npm registry), sha256 \`${origSha256}\` |
| This archive | \`${fileName}\`, sha256 \`${sha256}\`, ${size} bytes |
| Built by | \`tools/build_tampered.mjs\` (deterministic) |

## What was planted

${res.planted.map((x) => `- **${x.kind}** in \`${x.path}\` (${x.location}). ${x.description}`).join('\n')}

## Expected result

**Overall classification:** \`${fx.classification}\`

| Path | Location | Classification | Why |
|---|---|---|---|
${res.findings.map((x) => `| \`${x.path}\` | ${x.location} | \`${x.classification}\` | ${x.evidence} |`).join('\n')}

Every other file in the archive should produce no finding. They are byte-identical to source at the release commit.

## Notes

${res.notes.map((n) => `- ${n}`).join('\n')}

## Exact diff against the base archive

\`\`\`diff
${diff.trimEnd()}
\`\`\`
`;
  fs.writeFileSync(path.join(dir, 'PROVENANCE.md'), md);
  manifest.push({ fixture_id: record.fixture_id, archive: `${fx.id}/${fileName}`, sha256, size_bytes: size, expected: fx.classification });
  console.log(`built ${fx.id}  ${size}B  ${sha256.slice(0, 12)}…  -> ${fx.classification}`);
}

fs.writeFileSync(path.join(OUT, 'manifest.json'),
  JSON.stringify({ label: LABEL, split: 'dev', base_archive: 'ms-2.1.3.orig.tgz', base_archive_sha256: origSha256, fixtures: manifest }, null, 2) + '\n');
fs.rmSync(tmp, { recursive: true, force: true });
