#!/usr/bin/env bash
# Re-verifies the control releases: downloads each tarball, checks sha1 vs the npm registry,
# fetches the source commit, and compares files. Runs NO package code and NO build step.
# Usage: bash tools/verify_controls.sh   (needs network access to registry.npmjs.org and github.com)
W="${W:-$(pwd)/work}"; TSV="${TSV:-$(dirname "$0")/controls.tsv}"
while IFS=$'\t' read -r -u 3 name ver url sha dir; do
  slug=$(echo "$name" | sed 's#^@##; s#/#__#')
  echo "################ $name@$ver  (slug=$slug)"
  tgz=$(npm view "$name@$ver" dist.tarball </dev/null)
  want=$(npm view "$name@$ver" dist.shasum </dev/null)
  mkdir -p "$W/$slug/pkg" "$W/$slug/src"
  curl -sSfL "$tgz" -o "$W/$slug/$slug.tgz" </dev/null || { echo "DOWNLOAD FAIL"; continue; }
  got=$(sha1sum "$W/$slug/$slug.tgz" | cut -d' ' -f1)
  [ "$got" = "$want" ] && echo "sha1 OK $got" || echo "SHA MISMATCH got=$got want=$want"
  tar -xzf "$W/$slug/$slug.tgz" -C "$W/$slug/pkg" --strip-components=1
  ( cd "$W/$slug/src" && git init -q . </dev/null && git fetch -q --depth 1 "$url" "$sha" </dev/null 2>&1 | tail -2 ; git checkout -q FETCH_HEAD </dev/null && echo "commit $(git rev-parse HEAD)" )
  ( cd "$W/$slug/pkg"
    find . -type f | sort | while read -r f; do
      s="$W/$slug/src/$dir/$f"
      if [ -f "$s" ]; then cmp -s "$f" "$s" && st=IDENTICAL || st=DIFFERS; else st=ABSENT_IN_SOURCE; fi
      printf "  %-17s %s\n" "$st" "$f"
    done )
done 3< "$TSV"
