# VAJRA evaluation fixtures

> FIXTURES. Everything under `fixtures/` is test data for VAJRA development. The tampered archives are synthetic, are not real npm releases, and must never be published or installed outside a sandbox.

## Layout

- `fixtures/dev/controls/`: 8 real, unmodified npm releases with source commits and expected packaging noise (`CONTROLS.md`, `controls.json`).
- `fixtures/dev/tampered/ms-2.1.3/`: the pristine `ms@2.1.3` tarball plus six tampered copies. Each has `fixture.json` (machine-readable expectations) and `PROVENANCE.md` (human-readable note).
- `fixtures/heldout/`: empty on purpose. See its README.
- `tools/build_tampered.mjs`: rebuilds the six tampered archives deterministically from the pristine tarball.
- `tools/verify_controls.sh`, `tools/controls.tsv`: re-verify the controls.

## Classifications used

`suspicious_change`, `unresolved`, `explained_packaging`.

## Safety

- No package code, lifecycle script or build step was run to create these. Only file edits, repacking, hashing and diffs.
- Planted network calls point at `fixture.invalid` (a reserved TLD that never resolves). The postinstall call is also gated behind `VAJRA_FIXTURE_ALLOW_NET=1`, which nothing sets. Planted files only print `VAJRA_FIXTURE_MARKER:*` lines.
- No secrets, tokens or credentials are included.

## Rebuild

    node tools/build_tampered.mjs      # byte-identical output every run
    bash tools/verify_controls.sh      # needs network, builds nothing
